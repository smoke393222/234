# Руководство по развертыванию на VPS

Полное пошаговое руководство по установке и запуску VPN бота на удаленном VPS сервере.

---

## 🚀 Быстрый старт (для опытных пользователей)

```bash
# 1. Подключитесь к VPS
ssh root@your-server-ip

# 2. Установите Docker (если нужно)
curl -fsSL https://get.docker.com | sh

# 3. Клонируйте/загрузите проект
cd /opt && mkdir vpn-bot && cd vpn-bot
# (загрузите файлы проекта)

# 4. Настройте конфигурацию
cp env.example .env
nano .env  # Заполните BOT_TOKEN, ADMIN_TG_ID, XUI_*

# 5. Запустите бот
chmod +x deploy.sh
./deploy.sh

# Готово! Бот запущен.
```

Для детальной инструкции читайте дальше.

---

## Предварительные требования

### На вашем VPS должно быть установлено:
- Ubuntu 20.04+ (или другой Linux дистрибутив)
- Docker и Docker Compose
- Доступ по SSH
- Открытые порты для 3x-ui панели

### Что вам понадобится:
1. **Telegram Bot Token** - получите у [@BotFather](https://t.me/BotFather)
2. **Ваш Telegram ID** - узнайте у [@userinfobot](https://t.me/userinfobot)
3. **Рабочая панель 3x-ui** с настроенными инбаундами
4. **Данные для входа в 3x-ui** (username и password)

---

## Шаг 1: Подключение к VPS

```bash
ssh root@your-server-ip
# или
ssh your-user@your-server-ip
```

---

## Шаг 2: Установка Docker (если еще не установлен)

### Для Ubuntu/Debian:

```bash
# Обновляем систему
sudo apt update && sudo apt upgrade -y

# Устанавливаем необходимые пакеты
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common

# Добавляем официальный GPG ключ Docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Добавляем репозиторий Docker
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Устанавливаем Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Проверяем установку
docker --version
docker compose version
```

### Для CentOS/RHEL:

```bash
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo systemctl start docker
sudo systemctl enable docker
```

---

## Шаг 3: Создание директории для проекта

```bash
# Создаем директорию для бота
mkdir -p /opt/vpn-bot
cd /opt/vpn-bot
```

---

## Шаг 4: Загрузка файлов проекта

### Вариант A: Через Git (рекомендуется)

```bash
# Если у вас проект в Git репозитории
git clone https://github.com/your-username/vpn-bot.git .

# Или если используете приватный репозиторий
git clone https://your-token@github.com/your-username/vpn-bot.git .
```

### Вариант B: Через SCP (копирование с локального компьютера)

На вашем **локальном компьютере**:

```bash
# Из директории с проектом
scp -r * root@your-server-ip:/opt/vpn-bot/

# Или архивом
tar -czf vpn-bot.tar.gz *
scp vpn-bot.tar.gz root@your-server-ip:/opt/vpn-bot/
```

На **VPS сервере**:

```bash
cd /opt/vpn-bot
tar -xzf vpn-bot.tar.gz
rm vpn-bot.tar.gz
```

### Вариант C: Ручное создание файлов

Если файлов немного, можно создать их вручную через nano/vim.

---

## Шаг 5: Настройка конфигурации

```bash
# Копируем пример конфигурации
cp .env.example .env

# Редактируем конфигурацию
nano .env
```

### Заполните следующие параметры:

```env
# Токен вашего бота от @BotFather
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# Ваш Telegram ID (администратор)
ADMIN_TG_ID=123456789

# URL вашей панели 3x-ui (IP или домен)
XUI_BASE_URL=https://your-server.com:2053
# или
XUI_BASE_URL=http://localhost:2053

# Данные для входа в панель 3x-ui
XUI_USERNAME=admin
XUI_PASSWORD=your_password

# Опциональные настройки (используются как fallback)
VLESS_SERVER=your-server.com
VLESS_PORT=443
VLESS_SNI=your-server.com
```

**Важно:**
- `XUI_BASE_URL` - если 3x-ui на том же сервере, используйте `http://localhost:порт`
- Если 3x-ui на другом сервере, используйте полный URL с протоколом
- Убедитесь, что бот может достучаться до панели 3x-ui

Сохраните файл: `Ctrl+X`, затем `Y`, затем `Enter`

---

## Шаг 6: Проверка структуры проекта

```bash
# Убедитесь, что все файлы на месте
ls -la

# Должны быть:
# - Dockerfile
# - docker-compose.yml
# - requirements.txt
# - .env
# - bot/ (директория)
# - core/ (директория)
# - database/ (директория)
# - services/ (директория)
# - utils/ (директория)
```

---

## Шаг 7: Запуск бота

```bash
# Сборка и запуск в фоновом режиме
docker compose up -d --build

# Проверка статуса
docker compose ps

# Просмотр логов
docker compose logs -f

# Для выхода из логов нажмите Ctrl+C
```

---

## Шаг 8: Проверка работы

1. Откройте Telegram и найдите вашего бота
2. Отправьте команду `/start`
3. Проверьте, что бот отвечает

### Если бот не отвечает:

```bash
# Проверьте логи на ошибки
docker compose logs

# Проверьте, что контейнер запущен
docker compose ps

# Перезапустите бот
docker compose restart
```

---

## Управление ботом

### Основные команды:

```bash
# Просмотр логов в реальном времени
docker compose logs -f

# Просмотр последних 100 строк логов
docker compose logs --tail=100

# Остановка бота
docker compose down

# Запуск бота
docker compose up -d

# Перезапуск бота
docker compose restart

# Пересборка и запуск (после изменения кода)
docker compose up -d --build

# Просмотр использования ресурсов
docker stats vpn_bot
```

### Обновление бота:

```bash
cd /opt/vpn-bot

# Если используете Git
git pull

# Пересборка и перезапуск
docker compose down
docker compose up -d --build
```

---

## Автозапуск при перезагрузке сервера

Docker Compose уже настроен на автозапуск (`restart: unless-stopped`).

Проверить:

```bash
# Перезагрузите сервер
sudo reboot

# После перезагрузки подключитесь и проверьте
docker compose ps
```

---

## Настройка Systemd (альтернативный способ)

Если хотите управлять ботом через systemd:

```bash
# Создайте service файл
sudo nano /etc/systemd/system/vpn-bot.service
```

Содержимое:

```ini
[Unit]
Description=VPN Telegram Bot
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/vpn-bot
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
```

Активация:

```bash
sudo systemctl daemon-reload
sudo systemctl enable vpn-bot
sudo systemctl start vpn-bot
sudo systemctl status vpn-bot
```

---

## Резервное копирование

### Бэкап базы данных:

```bash
# Создайте директорию для бэкапов
mkdir -p /opt/vpn-bot/backups

# Создайте бэкап
docker compose exec bot cp /app/data/vpn_bot.db /app/backups/vpn_bot_$(date +%Y%m%d_%H%M%S).db

# Или скопируйте напрямую
cp /opt/vpn-bot/data/vpn_bot.db /opt/vpn-bot/backups/vpn_bot_$(date +%Y%m%d_%H%M%S).db
```

### Автоматический бэкап (cron):

```bash
# Откройте crontab
crontab -e

# Добавьте строку для ежедневного бэкапа в 3:00
0 3 * * * cp /opt/vpn-bot/data/vpn_bot.db /opt/vpn-bot/backups/vpn_bot_$(date +\%Y\%m\%d).db

# Удаление старых бэкапов (старше 30 дней)
0 4 * * * find /opt/vpn-bot/backups -name "vpn_bot_*.db" -mtime +30 -delete
```

---

## Мониторинг и логи

### Просмотр логов:

```bash
# Логи Docker контейнера
docker compose logs -f

# Логи приложения (если настроена запись в файл)
tail -f /opt/vpn-bot/logs/bot.log

# Поиск ошибок в логах
docker compose logs | grep ERROR
```

### Мониторинг ресурсов:

```bash
# Использование CPU и памяти
docker stats vpn_bot

# Размер логов
du -sh /opt/vpn-bot/logs/
```

---

## Безопасность

### Рекомендации:

1. **Файрвол:**
```bash
# Разрешите только необходимые порты
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 443/tcp   # HTTPS для 3x-ui
sudo ufw enable
```

2. **Ограничьте доступ к .env файлу:**
```bash
chmod 600 /opt/vpn-bot/.env
```

3. **Регулярно обновляйте систему:**
```bash
sudo apt update && sudo apt upgrade -y
```

4. **Используйте SSH ключи вместо паролей**

5. **Настройте fail2ban для защиты от брутфорса**

---

## Устранение неполадок

### Проблема: Бот не запускается

```bash
# Проверьте логи
docker compose logs

# Проверьте конфигурацию
cat .env

# Проверьте, что все переменные заданы
docker compose config
```

### Проблема: Не подключается к 3x-ui

```bash
# Проверьте доступность панели
curl -k https://your-server.com:2053

# Проверьте из контейнера
docker compose exec bot curl -k http://localhost:2053

# Проверьте логи 3x-ui
# (зависит от того, как установлен 3x-ui)
```

### Проблема: Ошибки при создании клиента

1. Убедитесь, что инбаунды настроены в 3x-ui
2. Проверьте права доступа пользователя в 3x-ui
3. Проверьте логи бота для деталей ошибки

### Проблема: База данных повреждена

```bash
# Остановите бота
docker compose down

# Восстановите из бэкапа
cp /opt/vpn-bot/backups/vpn_bot_YYYYMMDD.db /opt/vpn-bot/data/vpn_bot.db

# Запустите бота
docker compose up -d
```

---

## Производительность

### Оптимизация Docker:

```bash
# Очистка неиспользуемых образов
docker system prune -a

# Ограничение ресурсов (в docker-compose.yml)
# Добавьте в секцию bot:
deploy:
  resources:
    limits:
      cpus: '0.5'
      memory: 512M
```

---

## Полезные ссылки

- [Docker документация](https://docs.docker.com/)
- [Docker Compose документация](https://docs.docker.com/compose/)
- [3x-ui GitHub](https://github.com/MHSanaei/3x-ui)
- [Aiogram документация](https://docs.aiogram.dev/)

---

## Контрольный чеклист

После развертывания проверьте:

- [ ] Docker и Docker Compose установлены
- [ ] Проект скопирован на сервер
- [ ] Файл .env настроен с правильными данными
- [ ] Бот запущен: `docker compose ps` показывает "Up"
- [ ] Бот отвечает на команду `/start` в Telegram
- [ ] Логи не содержат критических ошибок
- [ ] Настроены инбаунды через `/settings`
- [ ] Тестовая заявка обрабатывается корректно
- [ ] Настроен автоматический бэкап
- [ ] Файрвол настроен

---

## Поддержка

При возникновении проблем:

1. Проверьте логи: `docker compose logs`
2. Проверьте конфигурацию: `cat .env`
3. Проверьте доступность 3x-ui панели
4. Убедитесь, что все порты открыты
5. Проверьте версии Docker и Docker Compose

Удачного развертывания! 🚀
