# Быстрая установка на VPS

Краткое руководство для быстрого развертывания VPN бота на сервере.

## Что понадобится

1. VPS сервер с Ubuntu/Debian
2. Telegram бот токен (получите у [@BotFather](https://t.me/BotFather))
3. Ваш Telegram ID (узнайте у [@userinfobot](https://t.me/userinfobot))
4. Рабочая панель 3x-ui с логином и паролем

---

## Установка за 5 минут

### 1. Подключитесь к серверу

```bash
ssh root@your-server-ip
```

### 2. Установите Docker (если еще не установлен)

```bash
curl -fsSL https://get.docker.com | sh
```

### 3. Создайте директорию и загрузите проект

```bash
mkdir -p /opt/vpn-bot
cd /opt/vpn-bot
```

Загрузите файлы проекта одним из способов:

**Вариант A: Через Git**
```bash
git clone https://github.com/your-repo/vpn-bot.git .
```

**Вариант B: Через SCP с локального компьютера**
```bash
# На локальном компьютере из папки с проектом:
tar -czf vpn-bot.tar.gz *
scp vpn-bot.tar.gz root@your-server-ip:/opt/vpn-bot/

# На сервере:
cd /opt/vpn-bot
tar -xzf vpn-bot.tar.gz
rm vpn-bot.tar.gz
```

### 4. Настройте конфигурацию

```bash
cp env.example .env
nano .env
```

Заполните обязательные параметры:

```env
BOT_TOKEN=ваш_токен_от_BotFather
ADMIN_TG_ID=ваш_telegram_id
XUI_BASE_URL=http://localhost:2053
XUI_USERNAME=admin
XUI_PASSWORD=ваш_пароль
```

Сохраните: `Ctrl+X`, затем `Y`, затем `Enter`

### 5. Запустите бот

```bash
chmod +x deploy.sh
./deploy.sh
```

### 6. Проверьте работу

Откройте бота в Telegram и отправьте `/start`

---

## Управление ботом

```bash
# Просмотр логов
docker compose logs -f

# Остановка
docker compose down

# Перезапуск
docker compose restart

# Обновление
./update.sh
```

---

## Первичная настройка

После запуска бота:

1. Откройте бота в Telegram
2. Отправьте `/settings`
3. Выберите инбаунды, которые будут доступны пользователям
4. Отметьте нужные галочками ✅

Теперь бот готов к работе!

---

## Устранение проблем

### Бот не отвечает

```bash
# Проверьте логи
docker compose logs

# Проверьте статус
docker compose ps

# Перезапустите
docker compose restart
```

### Ошибка подключения к 3x-ui

Проверьте:
- Правильность `XUI_BASE_URL` (если 3x-ui на том же сервере, используйте `http://localhost:порт`)
- Правильность логина и пароля
- Доступность панели: `curl -k http://localhost:2053`

### База данных повреждена

```bash
# Восстановите из бэкапа
cp backups/vpn_bot_YYYYMMDD_HHMMSS.db data/vpn_bot.db
docker compose restart
```

---

## Автоматический бэкап

Настройте ежедневный бэкап через cron:

```bash
crontab -e
```

Добавьте строку:

```
0 3 * * * cp /opt/vpn-bot/data/vpn_bot.db /opt/vpn-bot/backups/vpn_bot_$(date +\%Y\%m\%d).db
```

---

## Полезные ссылки

- [Полное руководство по развертыванию](DEPLOYMENT.md)
- [Документация по управлению инбаундами](INBOUND_MANAGEMENT.md)
- [Основной README](README.md)

---

## Поддержка

При проблемах:
1. Проверьте логи: `docker compose logs`
2. Проверьте конфигурацию: `cat .env`
3. Убедитесь, что 3x-ui доступна
4. Проверьте версию Docker: `docker --version`

Удачи! 🚀
