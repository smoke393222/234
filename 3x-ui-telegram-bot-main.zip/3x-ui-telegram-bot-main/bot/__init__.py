"""Telegram bot package for 3x-ui VPN management."""

__version__ = "1.0.0"
