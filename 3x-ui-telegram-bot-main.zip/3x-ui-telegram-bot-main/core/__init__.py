"""Core package for configuration and logging."""
